package com.tekshapers.system_Test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SystemTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
